<?php

$_LANG['display_name'] = '中文简体';  //用于在语言切换下拉中显示
$_LANG['display_flag'] = 'CN'; //用于显示图片，使用国家代码大写


$_LANG['demo'] = '这里的语言变量会输出到模板！default 的 语言包';