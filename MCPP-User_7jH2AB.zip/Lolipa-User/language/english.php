<?php

$_LANG['display_name'] = 'English';  //用于在语言切换下拉中显示
$_LANG['display_flag'] = 'US'; //用于显示图片，使用国家代码大写


$_LANG['demo'] = 'The language variables here are output to the template！default 的 语言包';